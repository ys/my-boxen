# Fitbit Puppet Module for Boxen

Install the [Fitbit](http://www.fitbit.com) fitness tracker.

## Usage

```puppet
include fitbit
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.

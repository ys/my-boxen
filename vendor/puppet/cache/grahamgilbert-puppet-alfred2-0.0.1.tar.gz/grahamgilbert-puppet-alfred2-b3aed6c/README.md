# Alfred 2 Puppet Module for Boxen

Install [Alfred 2](http://www.alfredapp.com), an award-winning productivity application for Mac OS X

## Usage

```puppet
include alfred2
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.

# Arduino Puppet Module for Boxen

## Usage

```puppet
include arduino
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.

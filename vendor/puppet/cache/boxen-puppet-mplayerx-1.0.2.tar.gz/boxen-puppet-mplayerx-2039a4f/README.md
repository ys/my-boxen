# MPlayerX Puppet Module for Boxen [![Build Status](https://travis-ci.org/boxen/puppet-mplayerx.png?branch=master)](https://travis-ci.org/boxen/puppet-mplayerx)

Installs the MPlayerX Mac app.

## Usage

```puppet
include mplayerx
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
